package com.example.stepdefinitions;

import java.util.List;

import org.junit.Assert;


import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import com.capgemini.helper.ExcelRead;


import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ConferenceRegistrationSelenium {
	private  int row = 1;
	private  String baseUrl = "http://localhost:9998//";
	private  String path_to_driver = "D:\\srinivas_12sep_garg\\4th_6nov(TopUP)\\Spring_content_5nov\\github_sirinivas\\";
	private  WebDriver driver = null;
	private  WebElement firstnameelement = null;
	private  WebElement lastnameelement = null;
	private  WebElement emailelement = null;
	private  WebElement contactelement = null;
	private  WebElement noofpeopleattendingelement = null;
	private  Select select1 = null;

	private  WebElement addresselement = null;
	private  WebElement areanameelement = null;

	private  WebElement cityelement = null;
	private  Select select2 = null;

	private  WebElement stateelement = null;
	private  Select select3 = null;

	private  List<WebElement> btnelement = null;

	@Before
	public void setChromeDriver() {

		ExcelRead.doexcel();
		System.setProperty("webdriver.chrome.driver", path_to_driver + "chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get(baseUrl);
		firstnameelement = driver.findElement(By.id("txtFirstName"));
		lastnameelement = driver.findElement(By.id("txtLastName"));
		emailelement = driver.findElement(By.id("txtEmail"));
		contactelement = driver.findElement(By.id("txtPhone"));
		noofpeopleattendingelement = driver.findElement(By.name("size"));
		select1 = new Select(noofpeopleattendingelement);
		addresselement = driver.findElement(By.id("txtAddress1"));
		areanameelement = driver.findElement(By.id("txtAddress2"));
		cityelement = driver.findElement(By.name("city"));
		select2 = new Select(cityelement);
		stateelement = driver.findElement(By.name("state"));
		select3 = new Select(stateelement);
		btnelement = driver.findElements(By.xpath("//input[@type='radio']"));
		/*
		 * firstnameelement.sendKeys(ExcelRead.getConobj().get(row).getFirstName());
		 * lastnameelement.sendKeys(ExcelRead.getConobj().get(row).getLastName());
		 * emailelement.sendKeys(ExcelRead.getConobj().get(row).getEmail());
		 * contactelement.sendKeys(ExcelRead.getConobj().get(row).getContactNo());
		 * select1.selectByVisibleText(ExcelRead.getConobj().get(row).
		 * getNumberOfPeopleAttending());
		 * addresselement.sendKeys(ExcelRead.getConobj().get(row).getAddress()+", "
		 * +ExcelRead.getConobj().get(0).getBuildingName());
		 * areanameelement.sendKeys(ExcelRead.getConobj().get(row).getAreaName());
		 * select2.selectByVisibleText(ExcelRead.getConobj().get(row).getCity());
		 * select3.selectByVisibleText(ExcelRead.getConobj().get(row).getState()); {
		 * for(int i=0;i<btnelement.size();i++) { String str =
		 * btnelement.get(i).getAttribute("value");
		 * if(str.equalsIgnoreCase("member".trim())) {
		 * if(!btnelement.get(i).isSelected()) { btnelement.get(i).click(); } } else
		 * if(str.equalsIgnoreCase("non member".trim())) {
		 * if(!btnelement.get(i).isSelected()) { btnelement.get(i).click(); } } }
		 * 
		 * }
		 */

	}

	@After
	public  void closeDriver() {
		try {
			Thread.sleep(4000);
			driver.quit();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

/*	@Test
	public void callme() {
		try {
			i_am_on_Conference_registration_page();
			i_do_not_input_value_for_First_name();
			i_click_on_Next_link();
			alert_message_should_be_displayed_Please_fill_the_First_name();
			i_do_not_input_value_for_Last_name();
			i_click_on_Next_link();
			alert_message_should_be_displayed_Please_fill_the_Last_name();
			i_do_not_input_value_for_Email();
			i_click_on_Next_link();
			alert_message_should_be_displayed_Please_fill_the_Email();
			i_do_not_input_value_for_Contact_no();
			i_click_on_Next_link();
			alert_message_should_be_displayed_Please_fill_the_contact_no();
			i_do_not_select_Number_of_people_attending();
			i_click_on_Next_link();
			alert_message_should_be_displayed_Please_fill_the_Number_of_people_attending();
			i_do_not_input_value_for_Address();
			i_click_on_Next_link();
			alert_message_should_be_displayed_Please_fill_the_Building_Room_No();
			i_do_not_input_value_for_Area_name();
			i_click_on_Next_link();
			alert_message_should_be_displayed_Please_fill_the_Area_name();
			i_do_not_select_City_value();
			i_click_on_Next_link();
			alert_message_should_be_displayed_Please_select_city();
			i_do_not_select_State_value();
			i_click_on_Next_link();
			alert_message_should_be_displayed_Please_select_state();
			i_do_not_select_Membership_status();
			i_click_on_Next_link();
			alert_message_should_be_displayed_Please_Select_MemeberShip_status();
			user_input_all_valid_data();
		} catch (Throwable e) {
			e.printStackTrace();
		}

	}*/

	@Given("^I am on Conference registration page$")
	public void i_am_on_Conference_registration_page() throws Throwable {
		Assert.assertEquals(driver.getTitle(), "Conference Registration");
	}

	@When("^I do not input value for 'First name'$")
	public void i_do_not_input_value_for_First_name() throws Throwable {
		firstnameelement.clear();
	}

	@When("^I click on Next link$")
	public void i_click_on_Next_link() throws Throwable {
		driver.findElement(By.partialLinkText("Next")).click();
	}

	@Then("^Alert message should be displayed 'Please fill the First name'\\.$")
	public void alert_message_should_be_displayed_Please_fill_the_First_name() throws Throwable {
		Alert alert = driver.switchTo().alert();
		String str = alert.getText();
		Thread.sleep(2000);
		alert.accept();
		Assert.assertEquals(str, "Please fill the First Name");
	}

	@When("^I do not input value for 'Last name'$")
	public void i_do_not_input_value_for_Last_name() throws Throwable {
		firstnameelement.sendKeys(ExcelRead.getConobj().get(row).getFirstName());
		lastnameelement.clear();
		driver.findElement(By.partialLinkText("Next")).click();
	}

	@Then("^Alert message should be displayed 'Please fill the Last name'\\.$")
	public void alert_message_should_be_displayed_Please_fill_the_Last_name() throws Throwable {
		Alert alert = driver.switchTo().alert();
		String str = alert.getText();
		alert.accept();
		Assert.assertEquals(str, "Please fill the Last Name");
	}

	@When("^I do not input value for 'Email'$")
	public void i_do_not_input_value_for_Email() throws Throwable {
		lastnameelement.sendKeys(ExcelRead.getConobj().get(row).getLastName());
		emailelement.clear();
		driver.findElement(By.partialLinkText("Next")).click();
	}

	@Then("^Alert message should be displayed Please fill the 'Email'\\.$")
	public void alert_message_should_be_displayed_Please_fill_the_Email() throws Throwable {
		Alert alert = driver.switchTo().alert();
		String str = alert.getText();
		alert.accept();
		Assert.assertEquals(str, "Please fill the Email");
	}

	@When("^I do not input value for 'Contact no\\.'$")
	public void i_do_not_input_value_for_Contact_no() throws Throwable {
		emailelement.sendKeys(ExcelRead.getConobj().get(row).getEmail());
		contactelement.clear();
		driver.findElement(By.partialLinkText("Next")).click();
	}

	@Then("^Alert message should be displayed 'Please fill the Contact No.'\\.$")
	public void alert_message_should_be_displayed_Please_fill_the_contact_no() throws Throwable {
		Alert alert = driver.switchTo().alert();
		String str = alert.getText();
		alert.accept();
		Assert.assertEquals(str, "Please fill the Contact No.");
	}

	@When("^I do not select 'Number of people attending'$")
	public void i_do_not_select_Number_of_people_attending() throws Throwable {
		contactelement.sendKeys(ExcelRead.getConobj().get(row).getContactNo());
		driver.findElement(By.partialLinkText("Next")).click();
		// select1.deselectByVisibleText(ExcelRead.getConobj().get(row).getNumberOfPeopleAttending());
	}

	@Then("^Alert message should be displayed 'Please fill the Number of people attending'\\.$")
	public void alert_message_should_be_displayed_Please_fill_the_Number_of_people_attending() throws Throwable {
		Alert alert = driver.switchTo().alert();
		String str = alert.getText();
		alert.accept();
		Assert.assertEquals(str, "Please fill the Number of people attending");
	}

	@When("^I do not input value for 'Address'$")
	public void i_do_not_input_value_for_Address() throws Throwable {
		select1.selectByVisibleText(ExcelRead.getConobj().get(row).getNumberOfPeopleAttending());
		addresselement.clear();
		driver.findElement(By.partialLinkText("Next")).click();
	}

	@Then("^Alert message should be displayed 'Please fill the Building & Room No'\\.$")
	public void alert_message_should_be_displayed_Please_fill_the_Building_Room_No() throws Throwable {
		Alert alert = driver.switchTo().alert();
		String str = alert.getText();
		alert.accept();
		Assert.assertEquals(str, "Please fill the Building & Room No");
	}

	@When("^I do not input value for 'Area name'$")
	public void i_do_not_input_value_for_Area_name() throws Throwable {
		addresselement.sendKeys(
				ExcelRead.getConobj().get(row).getAddress() + ", " + ExcelRead.getConobj().get(row).getBuildingName());
		areanameelement.clear();
		driver.findElement(By.partialLinkText("Next")).click();
	}

	@Then("^Alert message should be displayed 'Please fill the Area name'\\.$")
	public void alert_message_should_be_displayed_Please_fill_the_Area_name() throws Throwable {
		Alert alert = driver.switchTo().alert();
		String str = alert.getText();
		alert.accept();
		Assert.assertEquals(str, "Please fill the Area name");
	}

	@When("^I do not select 'City' value$")
	public void i_do_not_select_City_value() throws Throwable {
		areanameelement.sendKeys(ExcelRead.getConobj().get(row).getAreaName());
		driver.findElement(By.partialLinkText("Next")).click();
		// select2.deselectByVisibleText(ExcelRead.getConobj().get(row).getCity());
	}

	@Then("^Alert message should be displayed 'Please select city'\\.$")
	public void alert_message_should_be_displayed_Please_select_city() throws Throwable {
		Alert alert = driver.switchTo().alert();
		String str = alert.getText();
		alert.accept();
		Assert.assertEquals(str, "Please select city");
	}

	@When("^I do not select 'State' value$")
	public void i_do_not_select_State_value() throws Throwable {
		select2.selectByVisibleText(ExcelRead.getConobj().get(row).getCity());
		driver.findElement(By.partialLinkText("Next")).click();
		// select3.deselectByVisibleText(ExcelRead.getConobj().get(row).getState());
	}

	@Then("^Alert message should be displayed 'Please select state'\\.$")
	public void alert_message_should_be_displayed_Please_select_state() throws Throwable {
		Alert alert = driver.switchTo().alert();
		String str = alert.getText();
		alert.accept();
		Assert.assertEquals(str, "Please select state");
	}

	@When("^I do not select 'Membership status'$")
	public void i_do_not_select_Membership_status() throws Throwable {
		select3.selectByVisibleText(ExcelRead.getConobj().get(row).getState());
		{
			for (int i = 0; i < btnelement.size(); i++) {
				String str = btnelement.get(i).getAttribute("value");
				if (str.equalsIgnoreCase("member".trim())) {
					if (!btnelement.get(i).isSelected()) {
						btnelement.get(i).click();
					}
				} else if (str.equalsIgnoreCase("non member".trim())) {
					if (!btnelement.get(i).isSelected()) {
						btnelement.get(i).click();
					}
				}
			}

		}
		driver.findElement(By.partialLinkText("Next")).click();

	}

	@Then("^Alert message should be displayed 'Please Select MemeberShip status'\\.$")
	public void alert_message_should_be_displayed_Please_Select_MemeberShip_status() throws Throwable {
		Alert alert = driver.switchTo().alert();
		String str = alert.getText();
		alert.accept();
		Assert.assertEquals(str, "Please Select MemeberShip status");
	}

	@Given("^User input all valid data$")
	public void user_input_all_valid_data() throws Throwable {
		firstnameelement.sendKeys(ExcelRead.getConobj().get(row).getFirstName());
		lastnameelement.sendKeys(ExcelRead.getConobj().get(row).getLastName());
		emailelement.sendKeys(ExcelRead.getConobj().get(row).getEmail());
		contactelement.sendKeys(ExcelRead.getConobj().get(row).getContactNo());
		select1.selectByVisibleText(ExcelRead.getConobj().get(row).getNumberOfPeopleAttending());
		addresselement.sendKeys(
				ExcelRead.getConobj().get(row).getAddress() + ", " + ExcelRead.getConobj().get(0).getBuildingName());
		areanameelement.sendKeys(ExcelRead.getConobj().get(row).getAreaName());
		select2.selectByVisibleText(ExcelRead.getConobj().get(row).getCity());
		select3.selectByVisibleText(ExcelRead.getConobj().get(row).getState());
		{
			for (int i = 0; i < btnelement.size(); i++) {
				String str = btnelement.get(i).getAttribute("value");
				if (str.equalsIgnoreCase("member".trim())) {
					if (!btnelement.get(i).isSelected()) {
						btnelement.get(i).click();
					}
				} else if (str.equalsIgnoreCase("non member".trim())) {
					if (!btnelement.get(i).isSelected()) {
						btnelement.get(i).click();
					}
				}
			}

		}
		driver.findElement(By.partialLinkText("Next")).click();
	}

	@Then("^Alert message should be displayed Personal details are validated\\.$")
	public void alert_message_should_be_displayed_Personal_details_are_validated() throws Throwable {
		Alert alert = driver.switchTo().alert();
		String str = alert.getText();
		alert.accept();
		Assert.assertEquals(str, "Personal details are validated.");
	}


	@Then("^It should navigate to 'PaymentDetails' page\\.$")
	public void it_should_navigate_to_PaymentDetails_page() throws Throwable {
		driver.findElement(By.partialLinkText("Next")).click();
		Assert.assertEquals(driver.getTitle(), "Payment Details");
	}

}
