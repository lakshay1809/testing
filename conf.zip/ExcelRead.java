package com.capgemini.helper;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.example.model.ConferenceRoomDetails;

public class ExcelRead {
	
	protected static List<ConferenceRoomDetails> conobj= new ArrayList<ConferenceRoomDetails>();
	public static List<ConferenceRoomDetails> getConobj() {
		return conobj;
	}
	
	public static void doexcel() {
		int rownum=1;
		try {
			FileInputStream file = new FileInputStream(
					new File("Assets/DummyData_Conference_Room.xlsx"));

			// Create Workbook instance holding reference to .xlsx file
			XSSFWorkbook workbook = new XSSFWorkbook(file);

			// Create a DataFormatter to format and get each cell's value as String
			DataFormatter dataFormatter = new DataFormatter();

			// Get first/desired sheet from the workbook
			XSSFSheet sheet = workbook.getSheetAt(0);

			// Iterate through each rows one by one
			Iterator<Row> rowIterator = sheet.iterator();
			while (rowIterator.hasNext()) {
				
				int count=1;
				ConferenceRoomDetails newobj= new ConferenceRoomDetails();
				
				Row row = rowIterator.next();
				// For each row, iterate through all the columns
				Iterator<Cell> cellIterator = row.cellIterator();

				while (cellIterator.hasNext()) {
					if(rownum==1) {
						break;
					}
					Cell cell = cellIterator.next();
					String cellValue = dataFormatter.formatCellValue(cell);
					switch(count) {
					case 1:
						newobj.setFirstName(cellValue);
						break;
					case 2:
						newobj.setLastName(cellValue);
						break;
					case 3:
						newobj.setEmail(cellValue);
						break;
					case 4:
						newobj.setContactNo(cellValue);
						break;
					case 5:
						newobj.setNumberOfPeopleAttending(cellValue);
						break;
					case 6:
						newobj.setAddress(cellValue);
						break;
					case 7:
						newobj.setBuildingName(cellValue);
						break;
					case 8:
						newobj.setAreaName(cellValue);
						break;
					case 9:
						newobj.setCity(cellValue);
						break;
					case 10:
						newobj.setState(cellValue);
						break;
					case 11:{
						if(cellValue.equalsIgnoreCase("yes".trim())){
							newobj.setMembershipStatus("member");
						}
						break;
					}
					case 12:{
						if(cellValue.equalsIgnoreCase("yes".trim())) {
							newobj.setMembershipStatus("non member");
						}
					}
					
					}
					count++;
				}
				rownum++;
				conobj.add(newobj);
			}
			file.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	public static void main(String[] args) {
//		doexcel();
//		System.out.println(conobj.get(1).getMembershipStatus());

		
	}

}
